# Armadillo Website

Simple armadillo-themed website.

## Features
- Earthy natural design
- Interactive fact button
- Easy to customize

## How to Use
Open index.html in your browser.
