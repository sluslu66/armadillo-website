function showFact() {
  const facts = [
    "Armadillos can roll into a ball to protect themselves.",
    "They have tough, bony plates covering their bodies.",
    "Armadillos are excellent diggers and burrowers."
  ];
  const randomFact = facts[Math.floor(Math.random() * facts.length)];
  alert(randomFact);
}
